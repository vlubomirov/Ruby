class Array
  def to_hash
    Hash[*self.flatten]
  end

  def index_by
    self.map {|name|
      arr1=name.split(" ")
      arr2=arr1[1]
      arr1[0]=arr1[0]+" "+arr2
      arr1=arr1.reverse()
      arr1=arr1.to_hash()

    }
  end

  def subarray(subarray)
    count=0
    self.each_cons(2) {
      |x|
      count+=1 if x==subarray
    }
    count
  end

  def occurrences_count
    arr=self.map {|x| self.select {|y| x==y}}
    arr=arr.map{|z| [z.first,z.count]}
   arr.to_hash

  end
  
  def densities
    
    arr1=self.occurrences_count()
   arr=[]
    c=0
   self.map{|x| 
        arr[c]=arr1.values_at(x)
        c+=1
      }
      p arr
    
      
  end

end

arr=[1,2,3,4,5,4,2,5]
arr1=["Johnny Depp","Samuel Jackson","Rejep Ivedick"];
p arr
p arr.to_hash()
p arr1.index_by()
p arr.subarray([1,2])
p arr.occurrences_count
arr.densities