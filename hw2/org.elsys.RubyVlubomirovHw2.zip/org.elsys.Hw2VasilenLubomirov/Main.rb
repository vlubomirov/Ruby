"Vasilen Lubomirov 11b 7-mi nomer"
"Task - https://docs.google.com/document/d/1DF14IHfXhcXVVYX8QRmOV-Ay5ZuJzP6mYvb05GvPa34/edit?pli=1"
"Zadachata e neizpulnena , zashtoto ne poddurga filter kakto i rechnik"

class Collections

  attr_accessor :songs, :songs_as_strings, :artists
  def initialize songs,artists
    @songs_as_strings = songs.lines.to_a.map {|l| l.chomp}
    @artists=artists
    @songs = Array.new
    parse

  end

  def parse
    songs_as_strings.map do |line|
      n, a, gs, t = line.split('.').map {|s| s.strip}
      g, s = gs.split(',').map {|x| x.strip}
      t = t.split(',').map {|x| x.strip} unless t.nil?
      @songs << Song.new(n, a, g, s, t)

    end
  end

  def printArr
    @songs.each {|x| x.print}
  end

  def find criteria={}
    @songs.each{|x| x.find(criteria)}
  end
end

class Song
  attr_accessor :song,:artist,:genre,:subgenre,:tags
  def initialize song,artist,genre,subgenre,tags
    @song,@artist,@genre,@subgenre=song,artist,genre,subgenre
    @tags=tags
    @tags=@tags.to_a
  end

  def print
    puts "#{@song} #{@artist} #{@genre} #{@subgendre} #{@tags}"
  end

  def find criteria

    c=criteria.length

   flag=0
    criteria.each {|key,value|
      value=value.select {|x| !x.include? "!"}
        if @song==value then  flag+=1 end
        if @artist==value then  flag+=1 end
        if @genre==value then  flag+=1 end
        if @subgenre==value then  flag+=1 end
        if @tags.include?(value)|| @tags==value then  flag+=1 end
        if key==1 then p "fag"
        if @song.include?(value) then flag=1 end
        if key==":filter" then if @song.include?(value) then flag+1
        end
        end
      end
    }
    if c==flag  then
      print
    end

  end

end

songs = File.open("#{Dir.pwd}/songs.txt", "r").read
artists = File.open("#{Dir.pwd}/artists.txt", "r").read
artists.delete! "{" 
artists.delete! "\n" 
artists.delete! "}"
artists.delete! ""
artists= artists.split(",").map {|s| s.to_s}
p artists
y = Collections.new(songs,artists)
y.find tags:%w[weird cool!]

